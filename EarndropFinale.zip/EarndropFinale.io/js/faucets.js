document.querySelectorAll('a.smooth-scroll').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
    e.preventDefault();

    document.querySelector(this.getAttribute('href')).scrollIntoView({
        behavior: 'smooth'
    });
    });
});

function outFuncFaucet() {
    var tooltip = document.getElementById("myTooltip" + link_id);
    tooltip.innerHTML = "Copy to clipboard";
}
function copyTextFaucets(e) {
    // Get the ID for the link
    var link_id = e.id

    // Get the text field
    var copyText = document.getElementById("faucet_url" + link_id);
  
    // Select the text field
    copyText.select();
    copyText.setSelectionRange(0, 99999); // For mobile devices
  
     // Copy the text inside the text field
    navigator.clipboard.writeText(copyText.value);

    // Alert text was copied
    var tooltip = document.getElementById("myTooltip" + link_id);
    tooltip.innerHTML = "Link copied!";
}